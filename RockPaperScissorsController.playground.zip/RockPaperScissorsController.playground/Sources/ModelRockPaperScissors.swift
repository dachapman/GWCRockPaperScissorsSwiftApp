import Foundation

// model for Rock, Paper, Scissors Game

public extension Int {
    var rand: Int {
        return Int(arc4random_uniform(UInt32(self)))
    }
}

public class ModelRockPaperScissors {
    public enum RPS {
        case rock
        case paper
        case scissors
    }
    
    // set default values
    public var human : RPS = .scissors
    public var computer : RPS = .scissors
    
    // initialize scores
    public var computerScore = 0
    public var humanScore = 0
    
    public init() {
    }
    
    // randomly generate the computer's choice
    public func randomlyAssign() -> RPS {
        let randomChoice = 3.rand
        switch randomChoice {
        case 0: return .rock
        case 1: return .paper
        default: return .scissors
        }
    }
    
    // determine the winner of the game according to rock, paper, scissors rules
    public func determineWinner() -> String {
        var winnerName = ""
        if computer == human {
            if computer == .rock {
                winnerName = "Computer chooses rock.\nTie!"
            } else if computer == .paper {
                winnerName = "Computer chooses paper.\nTie!"
            } else {
                winnerName = "Computer chooses scissors.\nTie!"
            }
        }
            // paper wraps rock
        else if computer == .paper && human == .rock {
            winnerName = "Computer chooses paper.\nComputer wins!"
            computerScore += 1
        } else if  human == .paper && computer == .rock {
            winnerName = "Computer chooses rock.\nYou win!"
            humanScore += 1
        }
        // rock smashes scissors
        if computer == .scissors && human == .rock {
            winnerName = "Computer chooses scissors.\nYou win!"
            humanScore += 1
        } else if human == .scissors && computer == .rock {
            winnerName = "Computer chooses rock.\nComputer wins!"
            computerScore += 1

        }
        // scissors cut paper
        if computer == .paper && human == .scissors {
            winnerName = "Computer chooses paper.\nYou win!"
            humanScore += 1
        } else if human == .paper && computer == .scissors {
            winnerName = "Computer chooses scissors.\nComputer wins!"
            computerScore += 1
        }
        return winnerName
    }
}
