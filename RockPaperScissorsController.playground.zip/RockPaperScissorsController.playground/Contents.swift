//: Playground - noun: a place where people can play

import UIKit
import Foundation
import PlaygroundSupport


class RockPaperScissorsController : UIViewController {
    
    // create an instance of the model
    let p = ModelRockPaperScissors()
    
    var rockButton = UIButton()
    var paperButton = UIButton()
    var scissorsButton = UIButton()
    var buttonGo = UIButton()
    var buttonReset = UIButton()
    var myViewButtons = UIView()
    var gameResult = UILabel()
    var score = UILabel()
    var allButtons = [UIButton]()
    
    // user must make a selection before the "play" button will do anything
    var userMadeSelection = false
    
    // define colors for buttons and backgrounds
    let rpsButtonColor = UIColor(red: 0.9, green: 0.9, blue: 0.95, alpha: 1.0)
    let buttonPanelColor = UIColor(red: 0.2, green: 0.5, blue: 0.4, alpha: 1.0)
    let selectedButton = UIColor(red: 0.25, green: 0.45, blue: 0.65, alpha: 1.0)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 0.0, green: 0.1, blue: 0.3, alpha: 1.0)
        
        // create frame that is background to the buttons
        myViewButtons.frame = CGRect(x: 0, y: 75, width: 400, height: 150)
        myViewButtons.backgroundColor = buttonPanelColor
        view.addSubview(myViewButtons)

        // used as a reference.  place buttons relative to this value
        let left = 15
        
        // make rock button
        rockButton = UIButton(frame: CGRect(x: left, y: 100, width: 100, height: 100))
        rockButton.backgroundColor = rpsButtonColor
        rockButton.setTitleColor(.black, for: UIControlState.normal)
        rockButton.setTitleColor(.red, for: UIControlState.selected)
        rockButton.titleLabel?.numberOfLines = 2
        rockButton.titleLabel?.textAlignment = .center
        rockButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        rockButton.titleLabel?.adjustsFontSizeToFitWidth = true
        rockButton.setTitle("🧗🏼‍♂️\nRock", for: UIControlState.normal)
        rockButton.layer.cornerRadius = 10
        rockButton.addTarget(self, action: #selector(updateUI(sender:)), for: .touchUpInside)
        view.addSubview(rockButton)
        allButtons.append(rockButton)

        // make paper button
        paperButton = UIButton(frame: CGRect(x: left + 120, y: 100, width: 100, height: 100))
        paperButton.backgroundColor = rpsButtonColor
        paperButton.setTitleColor(.black, for: UIControlState.normal)
        paperButton.setTitleColor(.red, for: UIControlState.selected)
        paperButton.titleLabel?.numberOfLines = 2
        paperButton.titleLabel?.textAlignment = .center
        paperButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        paperButton.titleLabel?.adjustsFontSizeToFitWidth = true
        paperButton.setTitle("📄\nPaper", for: UIControlState.normal)
        paperButton.layer.cornerRadius = 10
        paperButton.addTarget(self, action: #selector(updateUI(sender:)), for: .touchUpInside)
        view.addSubview(paperButton)
        allButtons.append(paperButton)
        
        // make scissors button
        scissorsButton = UIButton(frame: CGRect(x: left + 240, y: 100, width: 100, height: 100))
        scissorsButton.backgroundColor = rpsButtonColor
        scissorsButton.setTitleColor(.black, for: UIControlState.normal)
        scissorsButton.setTitleColor(.red, for: UIControlState.selected)
        scissorsButton.titleLabel?.numberOfLines = 2
        scissorsButton.titleLabel?.textAlignment = .center
        scissorsButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        scissorsButton.titleLabel?.adjustsFontSizeToFitWidth = true
        scissorsButton.setTitle("✂️\nScissors", for: UIControlState.normal)
        scissorsButton.layer.cornerRadius = 10
        scissorsButton.addTarget(self, action: #selector(updateUI), for: .touchUpInside)
        view.addSubview(scissorsButton)
        allButtons.append(scissorsButton)
        
        // make button for "Play!"
        buttonGo = UIButton(frame: CGRect(x: left + 120, y: 250, width: 100, height: 50))
        buttonGo.backgroundColor = UIColor(red: 0.2, green: 0.6, blue: 0.4, alpha: 1.0)
        buttonGo.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        buttonGo.setTitleColor(.black, for: UIControlState.normal)
        buttonGo.setTitleColor(.red, for: UIControlState.selected)
        buttonGo.setTitle("Play!", for: UIControlState.normal)
        buttonGo.layer.cornerRadius = 10
        buttonGo.addTarget(self, action: #selector(playGame), for: .touchUpInside)
        view.addSubview(buttonGo)
        
        // make button for "Again!"
        buttonReset = UIButton(frame: CGRect(x: left + 120, y: 250, width: 100, height: 50))
        buttonReset.backgroundColor = UIColor(red: 0.2, green: 0.6, blue: 0.4, alpha: 1.0)
        buttonReset.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        buttonReset.setTitle("Again!", for: UIControlState.normal)
        buttonReset.setTitleColor(.black, for: UIControlState.normal)
        buttonReset.setTitleColor(.red, for: UIControlState.selected)
        buttonReset.layer.cornerRadius = 10
        buttonReset.addTarget(self, action: #selector(resetGame), for: .touchUpInside)
        buttonReset.isHidden = true
        view.addSubview(buttonReset)
        
        // display the choices of each player and the result of the round
        gameResult = UILabel(frame: CGRect(x: 0, y: 500, width: view.bounds.width/2, height: 50))
        gameResult.textColor = .white
        gameResult.numberOfLines = 2
        gameResult.font = UIFont.boldSystemFont(ofSize: 24)
        gameResult.adjustsFontSizeToFitWidth = true
        gameResult.text = ""
        gameResult.textAlignment = .center
        gameResult.adjustsFontSizeToFitWidth = true
        view.addSubview(gameResult)
        
        // display a running score
        score = UILabel(frame: CGRect(x: 0, y: 600, width: view.bounds.width/2, height: 50))
        score.textColor = .white
        score.font = UIFont.boldSystemFont(ofSize: 24)
        score.text = "Computer: \(p.computerScore)   You: \(p.humanScore)"
        score.textAlignment = .center
        score.adjustsFontSizeToFitWidth = true
        view.addSubview(score)
    }
    
    // control when buttons are enabled
    func makeRPSButtonsUnclickable() {
        rockButton.isEnabled = false
        paperButton.isEnabled = false
        scissorsButton.isEnabled = false
    }
    func makeRPSButtonsClickable() {
        rockButton.isEnabled = true
        paperButton.isEnabled = true
        scissorsButton.isEnabled = true
    }
    
    // deal with the rock, paper, scissors buttons
    @objc func updateUI(sender: UIButton) {
        // make sure user has selected a button before allowing game to play
        userMadeSelection = true
        
        //  reset all buttons to default color before selecting
        for aButton in allButtons {
            aButton.backgroundColor = rpsButtonColor
        }
        
        // highlight selected button
        sender.backgroundColor = selectedButton
        
        // user's choice is set to the selected button
        if sender.title(for: UIControlState.selected) == "🧗🏼‍♂️\nRock" {
            p.human = .rock
        } else if sender.title(for: UIControlState.selected) == "📄\nPaper" {
            p.human = .paper
        } else {
            p.human = .scissors
        }
    }
    
    @objc func playGame(sender: UIButton) {
        // make sure user has selected rock, paper, or scissors
        if userMadeSelection {
            
            // don't allow buttons to be clicked until the user plays a new round
            makeRPSButtonsUnclickable()
            
            // assign a random choice to computer
            p.computer = p.randomlyAssign()
            
            // determine winner of the round
            gameResult.text = p.determineWinner()
            
            // control which button is visible: "play" or "again!"
            buttonReset.isHidden = false
            buttonGo.isHidden = true
            
            // define updated score
            score.text = "Computer: \(p.computerScore)   You: \(p.humanScore)"
        }
    }
    
    @objc func resetGame(sender: UIButton) {
        // reset button background colors
        paperButton.backgroundColor = rpsButtonColor
        rockButton.backgroundColor = rpsButtonColor
        scissorsButton.backgroundColor = rpsButtonColor
        
        paperButton.isSelected = false
        rockButton.isSelected = false
        scissorsButton.isSelected = false
        buttonGo.isSelected = false
        buttonReset.isSelected = false
        
        // make "play!" button visible
        buttonGo.isHidden = false
        buttonReset.isHidden = true
        
        userMadeSelection = false
        gameResult.text = ""
        
        // enable rock, paper, scissors buttons so they are ready for play!
        makeRPSButtonsClickable()
    }
    
}

let myVC = RockPaperScissorsController()
PlaygroundPage.current.liveView = myVC
